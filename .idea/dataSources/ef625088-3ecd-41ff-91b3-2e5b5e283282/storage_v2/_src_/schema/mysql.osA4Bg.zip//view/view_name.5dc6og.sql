create view view_name as
  select `mysql`.`brother_experiences`.`name`       AS `name`,
         `mysql`.`brother_experiences`.`company`    AS `company`,
         `mysql`.`brother_experiences`.`position`   AS `position`,
         `mysql`.`brother_experiences`.`location`   AS `location`,
         `mysql`.`brother_experiences`.`start_date` AS `start_date`,
         `mysql`.`brother_experiences`.`end_date`   AS `end_date`,
         `mysql`.`brother_experiences`.`bullets`    AS `bullets`
  from `mysql`.`brother_experiences`;

